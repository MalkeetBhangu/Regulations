/**
 * 
 @author Logicease
 *
 */
import React, {Component} from 'react';
import {
  View,
  Text,
  ActivityIndicator,
  StyleSheet,
  StatusBar,
  FlatList,
  TouchableOpacity,
  Platform,
  SafeAreaView,
  Image,
  ScrollView,
  DeviceEventEmitter,
  Dimensions,
} from 'react-native';
import Screen from '../screens/screen';
import Loading from '../component/loading';
import CacheService from '../services/cache_service';
import ApiService from '../services/api_service';
import OfflineDatabase from '../services/offlineDatabase';
import {scale, verticalScale, moderateScale} from 'react-native-size-matters';
import LinearGradient from 'react-native-linear-gradient';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import fonts from '../styles/fonts';
import BackgroundSync from '../services/articles_background_sync';
import AntDesign from 'react-native-vector-icons/AntDesign';
import AsyncStorage from '@react-native-community/async-storage';
import {TabView, SceneMap, TabBar} from 'react-native-tab-view';
const initialLayout = {width: Dimensions.get('window').width};
const isWeb = Platform.OS === 'web';

export default class UpdateDescription extends Screen {
  constructor(props) {
    super(props);
    this.state = {
      description: this.props.navigation.state.params.description,
    };
  }
  render() {
    return (
      <View style={{flex: 1}}>
        <Text
          style={{
            textAlign: 'center',
            fontSize: moderateScale(15),
            fontWeight: '700',
          }}>
          {this.state.description}
        </Text>
      </View>
    );
  }
}
